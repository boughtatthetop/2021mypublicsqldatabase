# project43
Group 43 Digital Firm project


ERD = https://drawsql.app/group43-1/diagrams/latestone


main.py = FastAPI and API layer 

database_rest_and_creation.py = as it is written + it populates the database 




